/**
 * Jackkwest UAE End-of-Service Calculator — front-end logic.
 *
 * No external dependencies. No network requests. No tracking.
 * All calculation happens locally in the visitor's browser.
 *
 * Calculation basis: UAE Federal Decree-Law No. 33 of 2021 (as amended),
 * which unified end-of-service gratuity for all limited-term contracts:
 *   - Less than 1 year of service: no gratuity.
 *   - 1–5 years of service: 21 days' basic wage per year of service.
 *   - Beyond 5 years of service: 30 days' basic wage per year beyond year 5.
 *   - Total gratuity is capped at two years' total basic wage.
 * This is a general-purpose estimate; see the on-page disclaimer.
 */
( function () {
	'use strict';

	var i18n = ( window.uaegtcData && window.uaegtcData.i18n ) || {};

	function t( key, fallback ) {
		return i18n[ key ] || fallback;
	}

	function onReady( fn ) {
		if ( document.readyState === 'loading' ) {
			document.addEventListener( 'DOMContentLoaded', fn );
		} else {
			fn();
		}
	}

	function formatCurrency( amount ) {
		var currency = t( 'currency', 'AED' );
		var rounded = Math.round( ( amount + Number.EPSILON ) * 100 ) / 100;
		var parts = rounded.toFixed( 2 ).split( '.' );
		parts[ 0 ] = parts[ 0 ].replace( /\B(?=(\d{3})+(?!\d))/g, ',' );
		return currency + ' ' + parts.join( '.' );
	}

	function parseDateInput( value ) {
		if ( ! value ) {
			return null;
		}
		// Expecting YYYY-MM-DD from <input type="date">.
		var parts = value.split( '-' );
		if ( parts.length !== 3 ) {
			return null;
		}
		var year = parseInt( parts[ 0 ], 10 );
		var month = parseInt( parts[ 1 ], 10 );
		var day = parseInt( parts[ 2 ], 10 );
		var date = new Date( year, month - 1, day );

		if (
			date.getFullYear() !== year ||
			date.getMonth() !== month - 1 ||
			date.getDate() !== day
		) {
			return null;
		}
		return date;
	}

	function daysBetween( start, end ) {
		var msPerDay = 1000 * 60 * 60 * 24;
		return Math.round( ( end.getTime() - start.getTime() ) / msPerDay );
	}

	/**
	 * Break a total number of days into whole years, months and days,
	 * using a calendar-aware walk from the start date rather than a
	 * fixed 365-day approximation, so the displayed breakdown matches
	 * what a person would count on a calendar.
	 */
	function calendarBreakdown( start, end ) {
		var years = end.getFullYear() - start.getFullYear();
		var months = end.getMonth() - start.getMonth();
		var days = end.getDate() - start.getDate();

		if ( days < 0 ) {
			months -= 1;
			var prevMonth = new Date( end.getFullYear(), end.getMonth(), 0 );
			days += prevMonth.getDate();
		}

		if ( months < 0 ) {
			years -= 1;
			months += 12;
		}

		return { years: years, months: months, days: days };
	}

	function setFieldError( inputEl, errorEl, message ) {
		if ( message ) {
			inputEl.classList.add( 'uaegtc-invalid' );
			inputEl.setAttribute( 'aria-invalid', 'true' );
			if ( errorEl ) {
				errorEl.textContent = message;
			}
			return false;
		}

		inputEl.classList.remove( 'uaegtc-invalid' );
		inputEl.removeAttribute( 'aria-invalid' );
		if ( errorEl ) {
			errorEl.textContent = '';
		}
		return true;
	}

	function calculateGratuity( basicSalary, totalQualifyingDays ) {
		var DAYS_PER_YEAR = 365;
		var dailyWage = basicSalary / 30;
		var yearsExact = totalQualifyingDays / DAYS_PER_YEAR;

		if ( yearsExact < 1 ) {
			return {
				eligible: false,
				dailyWage: dailyWage,
				tierOne: 0,
				tierTwo: 0,
				total: 0,
				capApplied: false,
			};
		}

		var tierOneYears = Math.min( yearsExact, 5 );
		var tierTwoYears = Math.max( yearsExact - 5, 0 );

		var tierOneAmount = dailyWage * 21 * tierOneYears;
		var tierTwoAmount = dailyWage * 30 * tierTwoYears;

		var total = tierOneAmount + tierTwoAmount;
		var cap = basicSalary * 24; // Two years' total basic wage.
		var capApplied = false;

		if ( total > cap ) {
			total = cap;
			capApplied = true;
		}

		return {
			eligible: true,
			dailyWage: dailyWage,
			tierOne: tierOneAmount,
			tierTwo: tierTwoAmount,
			total: total,
			capApplied: capApplied,
		};
	}

	function init() {
		var form = document.getElementById( 'uaegtc-form' );
		if ( ! form ) {
			return;
		}

		var salaryInput = document.getElementById( 'uaegtc-salary' );
		var startInput = document.getElementById( 'uaegtc-start-date' );
		var endInput = document.getElementById( 'uaegtc-end-date' );
		var unpaidDaysInput = document.getElementById( 'uaegtc-unpaid-days' );

		var salaryError = document.getElementById( 'uaegtc-salary-error' );
		var startError = document.getElementById( 'uaegtc-start-date-error' );
		var endError = document.getElementById( 'uaegtc-end-date-error' );

		var resultBox = document.getElementById( 'uaegtc-result' );
		var resultAmount = document.getElementById( 'uaegtc-result-amount' );
		var serviceLengthCell = document.getElementById( 'uaegtc-service-length' );
		var dailyWageCell = document.getElementById( 'uaegtc-daily-wage' );
		var tierOneCell = document.getElementById( 'uaegtc-tier-one' );
		var tierTwoCell = document.getElementById( 'uaegtc-tier-two' );
		var finalTotalCell = document.getElementById( 'uaegtc-final-total' );
		var capNote = document.getElementById( 'uaegtc-cap-note' );

		// Prevent selecting a start/end date in the future.
		var todayStr = new Date().toISOString().slice( 0, 10 );
		if ( startInput ) {
			startInput.setAttribute( 'max', todayStr );
		}
		if ( endInput ) {
			endInput.setAttribute( 'max', todayStr );
		}

		form.addEventListener( 'submit', function ( event ) {
			event.preventDefault();

			var isValid = true;

			var salaryValue = parseFloat( salaryInput.value );
			if ( isNaN( salaryValue ) || salaryValue <= 0 ) {
				isValid = setFieldError( salaryInput, salaryError, t( 'errorSalary', 'Please enter a valid basic monthly salary greater than zero.' ) ) && isValid;
			} else {
				setFieldError( salaryInput, salaryError, '' );
			}

			var startDate = parseDateInput( startInput.value );
			var today = new Date();
			today.setHours( 0, 0, 0, 0 );

			if ( ! startDate ) {
				isValid = setFieldError( startInput, startError, t( 'errorStartDate', 'Please enter a valid employment start date.' ) ) && isValid;
			} else if ( startDate > today ) {
				isValid = setFieldError( startInput, startError, t( 'errorFutureDate', 'Dates cannot be in the future.' ) ) && isValid;
			} else {
				setFieldError( startInput, startError, '' );
			}

			var endDate = parseDateInput( endInput.value );
			if ( ! endDate ) {
				isValid = setFieldError( endInput, endError, t( 'errorEndDate', 'Please enter a valid employment end date.' ) ) && isValid;
			} else if ( endDate > today ) {
				isValid = setFieldError( endInput, endError, t( 'errorFutureDate', 'Dates cannot be in the future.' ) ) && isValid;
			} else if ( startDate && endDate <= startDate ) {
				isValid = setFieldError( endInput, endError, t( 'errorEndBeforeStart', 'The end date must be after the start date.' ) ) && isValid;
			} else {
				setFieldError( endInput, endError, '' );
			}

			if ( ! isValid ) {
				resultBox.setAttribute( 'hidden', 'hidden' );
				return;
			}

			var unpaidDays = parseInt( unpaidDaysInput.value, 10 );
			if ( isNaN( unpaidDays ) || unpaidDays < 0 ) {
				unpaidDays = 0;
			}

			var totalDays = daysBetween( startDate, endDate );
			var qualifyingDays = Math.max( totalDays - unpaidDays, 0 );

			var breakdown = calendarBreakdown( startDate, endDate );
			var result = calculateGratuity( salaryValue, qualifyingDays );

			var yearsLabel = t( 'years', 'years' );
			var monthsLabel = t( 'months', 'months' );
			var daysLabel = t( 'days', 'days' );

			serviceLengthCell.textContent =
				breakdown.years + ' ' + yearsLabel + ', ' +
				breakdown.months + ' ' + monthsLabel + ', ' +
				breakdown.days + ' ' + daysLabel;

			dailyWageCell.textContent = formatCurrency( result.dailyWage );
			tierOneCell.textContent = formatCurrency( result.tierOne );
			tierTwoCell.textContent = formatCurrency( result.tierTwo );

			if ( ! result.eligible ) {
				finalTotalCell.textContent = formatCurrency( 0 );
				resultAmount.textContent = formatCurrency( 0 );
				capNote.hidden = true;
				capNote.textContent = '';

				var notice = document.createElement( 'p' );
				notice.className = 'uaegtc-hint';
				notice.textContent = t( 'notEligible', 'Not eligible: UAE law requires at least one full year of continuous service before gratuity is payable.' );

				var existingNotice = resultBox.querySelector( '.uaegtc-not-eligible-notice' );
				if ( existingNotice ) {
					existingNotice.remove();
				}
				notice.classList.add( 'uaegtc-not-eligible-notice' );
				resultAmount.insertAdjacentElement( 'afterend', notice );
			} else {
				var existingNotice2 = resultBox.querySelector( '.uaegtc-not-eligible-notice' );
				if ( existingNotice2 ) {
					existingNotice2.remove();
				}

				resultAmount.textContent = formatCurrency( result.total );
				finalTotalCell.textContent = formatCurrency( result.total );

				if ( result.capApplied ) {
					capNote.hidden = false;
					capNote.textContent = t( 'capApplied', 'The two-year salary cap has been applied to this result.' );
				} else {
					capNote.hidden = true;
					capNote.textContent = '';
				}
			}

			resultBox.removeAttribute( 'hidden' );
			resultBox.scrollIntoView( { behavior: 'smooth', block: 'nearest' } );
		} );
	}

	onReady( init );
} )();
