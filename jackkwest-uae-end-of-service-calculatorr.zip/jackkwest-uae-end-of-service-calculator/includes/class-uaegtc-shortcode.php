<?php
/**
 * Shortcode handler for the Jackkwest UAE End-of-Service Calculator.
 *
 * @package UAE_Gratuity_Calculator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class UAEGTC_Shortcode
 *
 * Registers the [gratuity_calculator_uae] shortcode, enqueues its
 * assets only on pages/posts where the shortcode is actually used,
 * and renders the calculator markup.
 */
class UAEGTC_Shortcode {

	/**
	 * Shortcode tag.
	 *
	 * @var string
	 */
	const TAG = 'gratuity_calculator_uae';

	/**
	 * Hook everything up.
	 *
	 * @return void
	 */
	public function init() {
		add_shortcode( self::TAG, array( $this, 'render' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue_assets' ) );
	}

	/**
	 * Conditionally enqueue CSS/JS only when the current post contains
	 * the shortcode, so the plugin stays lightweight on every other page.
	 *
	 * @return void
	 */
	public function maybe_enqueue_assets() {
		if ( ! is_singular() ) {
			return;
		}

		global $post;

		if ( ! $post instanceof WP_Post ) {
			return;
		}

		if ( ! has_shortcode( $post->post_content, self::TAG ) ) {
			return;
		}

		$this->enqueue_assets();
	}

	/**
	 * Register and enqueue the plugin's front-end assets.
	 *
	 * @return void
	 */
	private function enqueue_assets() {
		wp_enqueue_style(
			'uaegtc-style',
			UAEGTC_PLUGIN_URL . 'assets/css/uae-gratuity-calculator.css',
			array(),
			UAEGTC_VERSION
		);

		wp_enqueue_script(
			'uaegtc-script',
			UAEGTC_PLUGIN_URL . 'assets/js/uae-gratuity-calculator.js',
			array(),
			UAEGTC_VERSION,
			true
		);

		wp_localize_script(
			'uaegtc-script',
			'uaegtcData',
			array(
				'i18n' => array(
					'errorSalary'      => esc_html__( 'Please enter a valid basic monthly salary greater than zero.', 'jackkwest-uae-end-of-service-calculator' ),
					'errorStartDate'   => esc_html__( 'Please enter a valid employment start date.', 'jackkwest-uae-end-of-service-calculator' ),
					'errorEndDate'     => esc_html__( 'Please enter a valid employment end date.', 'jackkwest-uae-end-of-service-calculator' ),
					'errorEndBeforeStart' => esc_html__( 'The end date must be after the start date.', 'jackkwest-uae-end-of-service-calculator' ),
					'errorFutureDate'  => esc_html__( 'Dates cannot be in the future.', 'jackkwest-uae-end-of-service-calculator' ),
					'notEligible'      => esc_html__( 'Not eligible: UAE law requires at least one full year of continuous service before gratuity is payable.', 'jackkwest-uae-end-of-service-calculator' ),
					'years'            => esc_html__( 'years', 'jackkwest-uae-end-of-service-calculator' ),
					'months'           => esc_html__( 'months', 'jackkwest-uae-end-of-service-calculator' ),
					'days'             => esc_html__( 'days', 'jackkwest-uae-end-of-service-calculator' ),
					'currency'         => esc_html__( 'AED', 'jackkwest-uae-end-of-service-calculator' ),
					'capApplied'       => esc_html__( 'The two-year salary cap has been applied to this result.', 'jackkwest-uae-end-of-service-calculator' ),
				),
			)
		);
	}

	/**
	 * Render the calculator shortcode.
	 *
	 * @param array $atts Shortcode attributes (currently unused, reserved for future options).
	 * @return string HTML markup for the calculator.
	 */
	public function render( $atts ) {
		// Reserved for future shortcode attributes (e.g. theme variants).
		$atts = shortcode_atts( array(), $atts, self::TAG );

		// If the shortcode is used somewhere has_shortcode() could not detect
		// (widgets, template parts via do_shortcode, etc.) make sure assets
		// still load.
		if ( ! wp_style_is( 'uaegtc-style', 'enqueued' ) ) {
			$this->enqueue_assets();
		}

		ob_start();
		?>
		<div class="uaegtc-calculator" id="uaegtc-calculator">
			<form class="uaegtc-form" id="uaegtc-form" novalidate>
				<h2 class="uaegtc-title"><?php esc_html_e( 'UAE Gratuity Calculator', 'jackkwest-uae-end-of-service-calculator' ); ?></h2>
				<p class="uaegtc-subtitle">
					<?php esc_html_e( 'Estimate your UAE end-of-service gratuity in seconds.', 'jackkwest-uae-end-of-service-calculator' ); ?>
				</p>

				<div class="uaegtc-field">
					<label for="uaegtc-salary"><?php esc_html_e( 'Basic monthly salary (AED)', 'jackkwest-uae-end-of-service-calculator' ); ?></label>
					<input
						type="number"
						id="uaegtc-salary"
						name="uaegtc_salary"
						class="uaegtc-input"
						min="0"
						step="0.01"
						inputmode="decimal"
						aria-describedby="uaegtc-salary-hint uaegtc-salary-error"
						required
					/>
					<p class="uaegtc-hint" id="uaegtc-salary-hint">
						<?php esc_html_e( 'Basic salary only — exclude housing, transport and other allowances.', 'jackkwest-uae-end-of-service-calculator' ); ?>
					</p>
					<p class="uaegtc-error" id="uaegtc-salary-error" role="alert"></p>
				</div>

				<div class="uaegtc-row">
					<div class="uaegtc-field">
						<label for="uaegtc-start-date"><?php esc_html_e( 'Employment start date', 'jackkwest-uae-end-of-service-calculator' ); ?></label>
						<input
							type="date"
							id="uaegtc-start-date"
							name="uaegtc_start_date"
							class="uaegtc-input"
							aria-describedby="uaegtc-start-date-error"
							required
						/>
						<p class="uaegtc-error" id="uaegtc-start-date-error" role="alert"></p>
					</div>

					<div class="uaegtc-field">
						<label for="uaegtc-end-date"><?php esc_html_e( 'Employment end date', 'jackkwest-uae-end-of-service-calculator' ); ?></label>
						<input
							type="date"
							id="uaegtc-end-date"
							name="uaegtc_end_date"
							class="uaegtc-input"
							aria-describedby="uaegtc-end-date-hint uaegtc-end-date-error"
							required
						/>
						<p class="uaegtc-hint" id="uaegtc-end-date-hint">
							<?php esc_html_e( 'Use today\'s date if you are still employed and want an estimate as of today.', 'jackkwest-uae-end-of-service-calculator' ); ?>
						</p>
						<p class="uaegtc-error" id="uaegtc-end-date-error" role="alert"></p>
					</div>
				</div>

				<div class="uaegtc-field">
					<label for="uaegtc-unpaid-days"><?php esc_html_e( 'Unpaid leave days taken (optional)', 'jackkwest-uae-end-of-service-calculator' ); ?></label>
					<input
						type="number"
						id="uaegtc-unpaid-days"
						name="uaegtc_unpaid_days"
						class="uaegtc-input"
						min="0"
						step="1"
						inputmode="numeric"
						aria-describedby="uaegtc-unpaid-days-hint"
					/>
					<p class="uaegtc-hint" id="uaegtc-unpaid-days-hint">
						<?php esc_html_e( 'Days of unpaid leave are not counted towards qualifying service and will be deducted from the total.', 'jackkwest-uae-end-of-service-calculator' ); ?>
					</p>
				</div>

				<div class="uaegtc-field">
					<label for="uaegtc-reason"><?php esc_html_e( 'Reason for leaving', 'jackkwest-uae-end-of-service-calculator' ); ?></label>
					<select id="uaegtc-reason" name="uaegtc_reason" class="uaegtc-input">
						<option value="resignation"><?php esc_html_e( 'Resignation', 'jackkwest-uae-end-of-service-calculator' ); ?></option>
						<option value="termination"><?php esc_html_e( 'Termination by employer', 'jackkwest-uae-end-of-service-calculator' ); ?></option>
						<option value="contract-end"><?php esc_html_e( 'End of fixed-term contract', 'jackkwest-uae-end-of-service-calculator' ); ?></option>
						<option value="still-employed"><?php esc_html_e( 'Still employed (estimate to date)', 'jackkwest-uae-end-of-service-calculator' ); ?></option>
					</select>
					<p class="uaegtc-hint">
						<?php esc_html_e( 'Since the 2022 UAE Labour Law reform, gratuity is calculated the same way regardless of the reason for leaving, provided the minimum one-year service requirement is met. This field is kept for your own records.', 'jackkwest-uae-end-of-service-calculator' ); ?>
					</p>
				</div>

				<button type="submit" class="uaegtc-submit">
					<?php esc_html_e( 'Calculate gratuity', 'jackkwest-uae-end-of-service-calculator' ); ?>
				</button>
			</form>

			<div class="uaegtc-result" id="uaegtc-result" aria-live="polite" hidden>
				<h3 class="uaegtc-result-title"><?php esc_html_e( 'Your estimated gratuity', 'jackkwest-uae-end-of-service-calculator' ); ?></h3>

				<div class="uaegtc-result-amount" id="uaegtc-result-amount">AED 0.00</div>

				<div class="uaegtc-breakdown">
					<table class="uaegtc-breakdown-table">
						<tbody>
							<tr>
								<th scope="row"><?php esc_html_e( 'Total length of service', 'jackkwest-uae-end-of-service-calculator' ); ?></th>
								<td id="uaegtc-service-length">—</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e( 'Daily basic wage', 'jackkwest-uae-end-of-service-calculator' ); ?></th>
								<td id="uaegtc-daily-wage">—</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e( 'Gratuity for first 5 years (21 days/year)', 'jackkwest-uae-end-of-service-calculator' ); ?></th>
								<td id="uaegtc-tier-one">—</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e( 'Gratuity beyond 5 years (30 days/year)', 'jackkwest-uae-end-of-service-calculator' ); ?></th>
								<td id="uaegtc-tier-two">—</td>
							</tr>
							<tr class="uaegtc-breakdown-total">
								<th scope="row"><?php esc_html_e( 'Final estimated gratuity', 'jackkwest-uae-end-of-service-calculator' ); ?></th>
								<td id="uaegtc-final-total">—</td>
							</tr>
						</tbody>
					</table>
					<p class="uaegtc-cap-note" id="uaegtc-cap-note" hidden></p>
				</div>

				<p class="uaegtc-disclaimer">
					<strong><?php esc_html_e( 'Disclaimer:', 'jackkwest-uae-end-of-service-calculator' ); ?></strong>
					<?php esc_html_e( 'This tool provides an estimate only, based on the general end-of-service gratuity rules under UAE Federal Decree-Law No. 33 of 2021 and its amendments. It does not constitute legal or financial advice. Free zone and mainland contracts, individual employment agreements, unpaid leave, disciplinary deductions and other factors can affect your actual entitlement. Always verify your specific case with your employer, a licensed UAE labour lawyer, or the UAE Ministry of Human Resources and Emiratisation (MoHRE).', 'jackkwest-uae-end-of-service-calculator' ); ?>
				</p>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}
}
