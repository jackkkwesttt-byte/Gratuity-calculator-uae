=== Jackkwest UAE End-of-Service Calculator ===
Contributors: jackkwest
Tags: gratuity, uae, end of service, calculator, hr
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A fast, self-contained shortcode calculator that estimates UAE end-of-service gratuity based on basic salary and length of service.

== Description ==

**Jackkwest UAE End-of-Service Calculator** adds a clean, accurate, self-contained end-of-service benefit calculator to any WordPress page or post using a simple shortcode.

Visitors enter their basic monthly salary, employment start date, employment end date, and (optionally) unpaid leave days and reason for leaving. The plugin instantly calculates:

* Total length of service (years, months and days)
* Daily basic wage
* Gratuity owed for the first five years of service (21 days per year)
* Gratuity owed for service beyond five years (30 days per year)
* Final estimated gratuity amount, with the statutory two-year salary cap applied automatically
* A full calculation breakdown and a clear disclaimer

The calculation follows the general end-of-service gratuity framework introduced by UAE Federal Decree-Law No. 33 of 2021 (as amended), which unified gratuity treatment for limited-term contracts regardless of whether the employee resigned or was terminated, subject to completing the minimum one year of continuous service.

= Why use this plugin =

* **Genuinely useful, not a link farm.** The calculator runs entirely in the visitor's browser — no data is submitted anywhere, no accounts are required, and no content is duplicated from other sources.
* **No dependencies.** Works immediately after activation. No Elementor, WooCommerce, or other plugin required.
* **No tracking, no ads, no popups.** The plugin does not load any analytics, advertising, or third-party scripts of any kind.
* **Privacy-friendly by design.** All inputs and results stay in the visitor's browser; nothing is stored in the WordPress database and nothing is sent to any external server.
* **Accessible markup.** Proper form labels, ARIA attributes for errors and live results, and keyboard-friendly controls.
* **Theme-safe styling.** All CSS classes are prefixed with `uaegtc-` and scoped under a single wrapper so the plugin will not clash with your active theme.
* **Translation-ready.** All strings are wrapped for internationalization.

= How the calculation works =

1. Length of qualifying service is calculated from the start and end dates you provide, minus any unpaid leave days.
2. If total qualifying service is less than one year, no gratuity is payable and the calculator explains why.
3. For the first five years of service, gratuity accrues at 21 days' basic wage per year.
4. For any service beyond five years, gratuity accrues at 30 days' basic wage per year.
5. The total is capped at two years' total basic wage, in line with the statutory maximum.

This is a general-purpose estimate intended for informational use. It does not account for every possible contractual, free-zone-specific, or company-policy variation. Always verify your exact entitlement with your employer, a licensed UAE labour lawyer, or the UAE Ministry of Human Resources and Emiratisation (MoHRE).

= External services =

This plugin does not connect to, or send any data to, any external service, API, or server. All calculations are performed locally in the visitor's browser using vanilla JavaScript. No cookies are set and no analytics or advertising scripts are loaded.

= A note on our website =

This plugin is developed and maintained by the team behind [UAE Gratuity Calculator](https://thegratuitycalculatoruae.com/), a website focused on UAE end-of-service benefit information. You'll find a link to the website in this readme and on the plugin's WordPress.org listing page; the plugin does not insert any link, credit, or attribution into your site's front end.

== Installation ==

= From your WordPress dashboard =

1. Navigate to **Plugins → Add New**.
2. Search for "Jackkwest UAE End-of-Service Calculator".
3. Click **Install Now**, then **Activate**.
4. Add the shortcode `[gratuity_calculator_uae]` to any page or post.

= Manual installation =

1. Download the plugin ZIP file.
2. Navigate to **Plugins → Add New → Upload Plugin** in your WordPress dashboard.
3. Select the ZIP file and click **Install Now**.
4. Activate the plugin through the **Plugins** menu.
5. Add the shortcode `[gratuity_calculator_uae]` to any page or post.

== Usage ==

Add the following shortcode to any page, post, or shortcode-enabled widget area:

`[gratuity_calculator_uae]`

The calculator will render with no additional configuration required. Styles and scripts are only loaded on pages where the shortcode is actually used, so the plugin adds no overhead anywhere else on your site.

== Frequently Asked Questions ==

= Does this plugin store any data? =

No. The plugin does not create any database tables, does not save form submissions, and does not use cookies or local storage. All calculations happen instantly in the visitor's browser and are discarded when the page is closed or refreshed.

= Does this plugin require any other plugin to work? =

No. It works immediately after activation with no dependencies on Elementor, WooCommerce, page builders, or any other plugin.

= Is the result a legally guaranteed gratuity amount? =

No. The calculator provides a general estimate based on the standard UAE end-of-service gratuity formula. Individual contracts, free zone regulations, unpaid leave, disciplinary deductions and other factors can affect the actual amount. Always confirm your specific entitlement with a qualified professional or MoHRE.

= Can I use this calculator in a language other than English? =

Yes. All strings are translation-ready. You can translate the plugin using standard WordPress translation tools (such as a `.po`/`.mo` file placed in the plugin's `languages` directory, or a translation plugin).

= Will this plugin slow down my site? =

No. Its CSS and JavaScript files are small, are only enqueued on pages that actually contain the shortcode, and there are no external requests of any kind.

= Does the plugin add any links to my site's front end? =

No. No credit link, badge, or attribution is inserted into your site's front end. Any reference to the plugin author's website appears only in this readme file and on the plugin's WordPress.org listing.

== Screenshots ==

1. The gratuity calculator form as shown on a page using the `[gratuity_calculator_uae]` shortcode.
2. The calculation breakdown and result shown after submitting the form.
3. The calculator displayed on a mobile-width viewport.

== Changelog ==

= 1.0.0 =
* Initial release: shortcode-based UAE gratuity calculator with full calculation breakdown, accessible markup, responsive design, and no external dependencies.

== Upgrade Notice ==

= 1.0.0 =
Initial release.
