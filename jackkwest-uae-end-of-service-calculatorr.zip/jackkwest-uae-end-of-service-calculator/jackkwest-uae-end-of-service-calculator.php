<?php
/**
 * Plugin Name:       Jackkwest UAE End-of-Service Calculator
 * Plugin URI:         https://thegratuitycalculatoruae.com/
 * Description:        A fast, accurate, self-contained UAE end-of-service gratuity calculator. Add the [gratuity_calculator_uae] shortcode to any page or post to let visitors estimate their end-of-service benefits under current UAE labour law.
 * Version:             1.0.0
 * Requires at least:   6.0
 * Requires PHP:        7.4
 * Author:              The Gratuity Calculator UAE
 * Author URI:          https://profiles.wordpress.org/jackkwest/profile/
 * License:             GPL v2 or later
 * License URI:         https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:         jackkwest-uae-end-of-service-calculator
 * Domain Path:         /languages
 *
 * @package UAE_Gratuity_Calculator
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Basic plugin constants.
define( 'UAEGTC_VERSION', '1.0.0' );
define( 'UAEGTC_PLUGIN_FILE', __FILE__ );
define( 'UAEGTC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'UAEGTC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'UAEGTC_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Require the plugin's core classes.
 */
require_once UAEGTC_PLUGIN_DIR . 'includes/class-uaegtc-shortcode.php';

/**
 * Boot the plugin.
 *
 * @return void
 */
function uaegtc_run() {
	$shortcode = new UAEGTC_Shortcode();
	$shortcode->init();
}
add_action( 'plugins_loaded', 'uaegtc_run', 20 );

/**
 * Nothing is written to the database by this plugin (no custom tables,
 * no options beyond WordPress core defaults), so activation/deactivation
 * hooks are intentionally minimal.
 */
function uaegtc_activate() {
	// Reserved for future use (e.g. capability checks). Intentionally empty.
}
register_activation_hook( __FILE__, 'uaegtc_activate' );

function uaegtc_deactivate() {
	// Intentionally empty — no persistent data is created by this plugin.
}
register_deactivation_hook( __FILE__, 'uaegtc_deactivate' );
